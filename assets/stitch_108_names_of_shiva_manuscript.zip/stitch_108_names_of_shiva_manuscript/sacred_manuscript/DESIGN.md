---
name: Sacred Manuscript
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#46464b'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#77767c'
  outline-variant: '#c7c6cc'
  surface-tint: '#5c5e68'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#191b23'
  on-primary-container: '#82838e'
  inverse-primary: '#c5c6d1'
  secondary: '#725b24'
  on-secondary: '#ffffff'
  secondary-container: '#fcdc98'
  on-secondary-container: '#775f28'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#171b2a'
  on-tertiary-container: '#7f8396'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e1ed'
  primary-fixed-dim: '#c5c6d1'
  on-primary-fixed: '#191b23'
  on-primary-fixed-variant: '#454650'
  secondary-fixed: '#ffdf9b'
  secondary-fixed-dim: '#e2c381'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#59440e'
  tertiary-fixed: '#dee1f7'
  tertiary-fixed-dim: '#c2c5da'
  on-tertiary-fixed: '#171b2a'
  on-tertiary-fixed-variant: '#424657'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  headline-display:
    fontFamily: EB Garamond
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 68px
    letterSpacing: 0.02em
  headline-display-mobile:
    fontFamily: EB Garamond
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: 0.01em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0.01em
  headline-md:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: EB Garamond
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
    letterSpacing: 0.01em
  body-md:
    fontFamily: EB Garamond
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: '0'
  body-sm:
    fontFamily: EB Garamond
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
spacing:
  gutter: 2rem
  margin: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system establishes a quiet digital sanctuary—a meditative, timeless space honoring the sacred invocation of the 108 names. The aesthetic harmonizes the tactile gravity of ancient inscribed vellum and palm-leaf manuscripts with the disciplined purity of modern high-end editorial book design. 

The core emotional response is reverence, stillness, and unbounded focus. Every interface element breathes; interactions do not demand attention but invite presence. Loud gamification cues, saturated accents, mechanical drop shadows, and high-frequency UI affordances are intentionally rejected in favor of hairline rules, subtle tonal shifts, and devotional typography.

## Colors

The palette draws inspiration from sacred ritual elements: deep mineral lampblack ink, aged parchment, and consecrated ritual brass.

- **Primary (`#13151D`)**: Midnight Lampblack. Used for foundational text, primary titles, and profound contrast. Retains deep charcoal warmth without the harshness of pure black.
- **Secondary (`#C5A869`)**: Muted Temple Gold. Used selectively for sacred markers, active mantra highlights, subtle accents, and sacred geometry focal nodes.
- **Tertiary (`#242838`)**: Consecrated Indigo. Used for contemplative layers, secondary structures, and night-reading depth surfaces.
- **Neutral (`#F9F7F2`)**: Warm Ivory Parchment. Serves as the primary canvas base, evoking hand-pressed cotton paper and soft ambient daylight.

### Supporting Tones
- **Sub-canvas & Card Fill (`#F3EFE6`, `#EAE5D9`)**: Tonal shifts for contemplation panels and reading frames.
- **Muted Brass Accent (`#9B8248`)**: Deeper metallic value for focused borders and active iconography.
- **Sacred Ink Muted (`#7C7F8C`, `#A09D94`)**: Soft slate and warm grey for transliteration, verse numbering, and secondary metadata.

## Typography

Typography functions as the voice of the manuscript. 

- **Primary Voice (`EB Garamond`)**: Deployed for Sanskrit transliterations, English meanings, philosophical commentaries, and sacred names. Its historical proportions, humanistic stroke modulation, and dignified italics evoke centuries of textual transmission.
- **System Counterpoint (`Plus Jakarta Sans`)**: Whisper-light, crisp, and neutral. Reserved strictly for non-sacred metadata: sequence indexing (e.g., `001 / 108`), audio duration, script toggles (Devanagari / IAST / English), and delicate interface navigation.

All label styles use uppercase casing with generous letter spacing to avoid competing with reading passages.

## Layout & Spacing

The layout is grounded in a symmetrical editorial column system inspired by illuminated folios. The reading experience prioritizes single-point contemplation: one name, one meaning, and one meditative reflection per screen, flanked by spacious margins that allow the eye to rest.

### Breakpoints & Structural Rules
- **Desktop (1024px and above)**: Central reading column constrained to a maximum of 680px for optimal line lengths, with 3rem outer margins (`margin`) and 2rem interior gutters (`gutter`). Supplementary commentaries sit comfortably within dual-column layouts where balanced.
- **Tablet (768px – 1023px)**: Single centered column with 2.5rem margins, preserving the wide-page folio feel.
- **Mobile (up to 767px)**: Fluid vertical reading flow with 1.25rem margins. Margins compress gently while vertical element gap (`space-xl`) between the Sanskrit name and its commentary remains expansive to preserve breathing room.

## Elevation & Depth

This system avoids floating UI paradigms, blurred glassmorphism, and synthetic cast shadows. Depth is communicated strictly through surface layering and delicate linework:

- **Tonal Inscription**: Depth is achieved through layered paper tones. The page background rests on `#F9F7F2`, while contemplation alcoves, audio panels, and commentary folios sit on `#F3EFE6` or `#EAE5D9`.
- **Hairline Framing**: Structural separation is defined by 0.5px to 1px hairline rules using `#13151D` at 10% to 15% opacity, or muted gold (`#C5A869`) at 30% opacity.
- **Focus Veil**: During mantra meditation mode, non-essential interface tiers fade into near-zero opacity, drawing the reader into uninterrupted focus.

## Shapes

Shapes adhere to an architectural, book-bound precision: sharp 90-degree corners (`0`), reminiscent of cut manuscript folios, stone tablets, and trimmed parchment leaves. 

Delicate micro-accents (such as corner flourishes, mandala geometric focal points, or square pagination indicators) reinforce the geometry of traditional yantras without rounding outer boundaries.

## Components

### Buttons & Interactive Links
- **Primary Sacred Action**: Clean, unrounded rectangular containers bordered with a 1px solid rule in `#C5A869` or `#13151D`. Transparent background; label in `label-md` tracking uppercase. On hover, fills subtly with `#F3EFE6` or inverts smoothly to `#13151D` with parchment-toned text.
- **Contemplative Icon Actions**: Minimalist hairline glyphs (audio listen, verse bookmark, deep focus mode) bordered only by generous invisible touch targets. No heavy container pills.

### Chips & Metadata Tags
- **Script & Mode Toggles**: Flat hairline boxes containing `label-sm` typography. Active states feature an underline or a muted gold border (`#C5A869`), never a thick badge background.
- **Attributes & Categories**: Raw text paired with a centered hairline dot divider (`·`), eliminating bubble chips entirely.

### Lists & Name Indices
- **Manuscript Index**: Ordered list displaying Sanskrit numerals or clean western indices (`001`, `002`), followed by the transliterated name and brief essence. Separated by subtle horizontal hairline borders (`#13151D` at 8% opacity). Generous vertical padding (`space-md` to `space-lg`).

### Form Controls & Inputs
- **Search & Filter Fields**: Underline-only inputs (border-bottom: 1px solid `#A09D94`). Focus transitions the border softly to `#C5A869`. Placeholder text rendered in `body-sm` italic Garamond.
- **Checkboxes & Radios**: Replaced with clean geometric squares or fine-lined concentric circles. Checked states display a centered solid diamond or gold micro-square.

### Contemplation Folio (Manuscript Card Alternative)
- **Folio Card**: In place of SaaS cards, content lives within an inscribed boundary. A subtle parchment surface (`#F3EFE6`) bordered by a 0.5px rule with optional corner notch accents. Contains the primary Sanskrit name in large display serif, followed by phonetic transliteration, literal meaning, and philosophical commentary.

### Domain-Specific Components
- **Mantra Bead Counter (Japa Guide)**: A quiet horizontal or circular hairline counter tracking completions without gamified celebration popups.
- **Audio Recitation Bar**: An understated audio controller featuring a single gold hairline progress line and play/pause glyph, accompanied by duration labels in `label-sm`.